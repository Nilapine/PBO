/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package pbo;

/**
 *
 * @author D2A
 */
public abstract class Bangun2D {

    public abstract void cetakLuas();

    public abstract void cetakKeliling();
}
