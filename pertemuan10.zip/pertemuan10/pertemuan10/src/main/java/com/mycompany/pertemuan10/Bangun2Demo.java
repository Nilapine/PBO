/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pertemuan10;

/**
 *
 * @author D2A
 */
public class Bangun2Demo {
    public static void main(String[]args)  {   
        BujurSangkar bs=new BujurSangkar(5);   
        bs.cetakKeliling();   
        bs.cetakLuas();     } 
}
