/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pertemuan10;

/**
 *
 * @author D2A
 */
public class Pertemuan10 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
