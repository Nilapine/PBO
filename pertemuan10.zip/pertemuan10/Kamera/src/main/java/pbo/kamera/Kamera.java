/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package pbo.kamera;

/**
 *
 * @author D2A
 */
public class Kamera {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
